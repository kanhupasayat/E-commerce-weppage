let b=docoment.body
console.log("first child of b is ",b.firstelementchild)
console.log("first element of child is ",b.firstelementchild)